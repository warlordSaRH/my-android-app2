package com.example.mutajri;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int GREEN = Color.rgb(22,138,74);
    final int DARK_GREEN = Color.rgb(18,107,59);
    final int PALE = Color.rgb(243,251,245);
    final int TEXT = Color.rgb(25,45,33);
    LinearLayout root, content;
    android.content.SharedPreferences prefs;
    String currentPage = "home";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("mutajri", MODE_PRIVATE);
        migrateOldData();
        buildShell();
        showHome();
    }

    JSONArray arr(String key) {
        try { return new JSONArray(prefs.getString(key,"[]")); }
        catch(Exception e) { return new JSONArray(); }
    }
    void save(String key, JSONArray a) { prefs.edit().putString(key,a.toString()).apply(); }
    String pref(String key,String def){ return prefs.getString(key,def); }
    void put(String key,String value){ prefs.edit().putString(key,value).apply(); }
    boolean activeShift(){ return prefs.getBoolean("shift_active",false); }
    String shiftId(){ return pref("shift_id",""); }
    String now(){ return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date()); }
    String dateOnly(){ return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()); }
    String displayDate(String s){
        try { return new SimpleDateFormat("dd/MM/yyyy",Locale.US).format(new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(s)); }
        catch(Exception e){ return s; }
    }
    double n(Object o){ try{return Double.parseDouble(String.valueOf(o));}catch(Exception e){return 0;} }

    JSONArray products(){ return arr("products"); }
    JSONArray sales(){ return arr("sales"); }
    JSONArray shifts(){ return arr("shifts"); }
    JSONArray customers(){ return arr("customers"); }

    void migrateOldData(){
        JSONArray s=arr("sales"); JSONArray out=new JSONArray(); boolean changed=false;
        for(int i=0;i<s.length();i++) try{
            Object x=s.get(i);
            if(x instanceof JSONObject) out.put(x);
            else { JSONObject o=new JSONObject(); o.put("total",n(x)); o.put("qty",1); o.put("product","بيع سابق"); o.put("time",now()); o.put("shiftId",""); out.put(o); changed=true; }
        }catch(Exception ignored){}
        if(changed) save("sales",out);
    }

    TextView tv(String s,float size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);
        t.setPadding(6,5,6,5); t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return t;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(15); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setGravity(Gravity.CENTER); b.setBackgroundResource(R.drawable.green_button); b.setPadding(10,2,10,2); return b;
    }
    LinearLayout card(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(16,12,16,12);
        l.setBackgroundResource(R.drawable.card_bg); l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); return l;
    }
    LinearLayout.LayoutParams lp(int h){ return new LinearLayout.LayoutParams(-1,h); }
    void addSpace(int h){ Space s=new Space(this); content.addView(s,new LinearLayout.LayoutParams(1,h)); }

    void buildShell(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(PALE); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(18,10,18,10); bar.setBackgroundColor(DARK_GREEN);
        TextView title=tv("متجري",22,Color.WHITE,true); bar.addView(title,new LinearLayout.LayoutParams(0,64,1)); root.addView(bar);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(14,14,14,8); content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView sc=new ScrollView(this); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        HorizontalScrollView navScroll=new HorizontalScrollView(this); navScroll.setFillViewport(true); navScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout nav=new LinearLayout(this); nav.setPadding(6,4,6,6); nav.setBackgroundColor(Color.WHITE); nav.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        String[] labels={"الرئيسية","المبيعات","المنتجات","العملاء والديون","التقارير","سجل الوردية"};
        for(String x:labels){ Button n=btn(x); n.setTextColor(GREEN); n.setBackgroundColor(Color.TRANSPARENT); n.setMinWidth(105);
            n.setOnClickListener(v->{ if(x.equals("الرئيسية"))showHome(); else if(x.equals("المبيعات"))showSales(); else if(x.equals("المنتجات"))showProducts(); else if(x.equals("العملاء والديون"))showCustomers(); else if(x.equals("التقارير"))showReports(); else showShiftHistory(); });
            nav.addView(n,new LinearLayout.LayoutParams(115,58)); }
        navScroll.addView(nav); root.addView(navScroll,new LinearLayout.LayoutParams(-1,66)); setContentView(root);
    }
    void clear(String title){ content.removeAllViews(); TextView h=tv(title,24,TEXT,true); h.setPadding(4,4,4,12); content.addView(h); }

    double currentShiftSales(){ double total=0; JSONArray a=sales(); for(int i=0;i<a.length();i++)try{JSONObject o=a.getJSONObject(i); if(shiftId().equals(o.optString("shiftId"))) total+=o.optDouble("total",0);}catch(Exception ignored){} return total; }
    int currentShiftCount(){ int c=0; JSONArray a=sales(); for(int i=0;i<a.length();i++)try{if(shiftId().equals(a.getJSONObject(i).optString("shiftId")))c++;}catch(Exception ignored){} return c; }
    double allSales(){double t=0; JSONArray a=sales(); for(int i=0;i<a.length();i++)try{t+=a.getJSONObject(i).optDouble("total",0);}catch(Exception ignored){} return t;}

    void showHome(){
        currentPage="home"; clear("السلام عليكم 👋");
        LinearLayout shift=card();
        shift.addView(tv(activeShift()?"الوردية الحالية":"لا توجد وردية نشطة",16,TEXT,true));
        if(activeShift()) shift.addView(tv("بدأت: "+pref("shift_start",""),13,Color.DKGRAY,false));
        Button shiftBtn=btn(activeShift()?"⏹ إنهاء الوردية":"▶ بدء الوردية");
        shiftBtn.setOnClickListener(v->{ if(activeShift())endShift(); else startShift(); });
        shift.addView(shiftBtn,lp(58)); content.addView(shift,lp(activeShift()?140:105)); addSpace(12);

        LinearLayout c=card(); c.addView(tv("مبيعات الوردية",14,Color.DKGRAY,false)); c.addView(tv(String.format(Locale.US,"%.0f ج.س",currentShiftSales()),28,GREEN,true)); content.addView(c,lp(110)); addSpace(10);
        LinearLayout row=new LinearLayout(this); row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout a=card(); a.addView(tv("المنتجات",14,Color.DKGRAY,false)); a.addView(tv(""+products().length(),26,GREEN,true));
        LinearLayout b=card(); b.addView(tv("عمليات البيع",14,Color.DKGRAY,false)); b.addView(tv(""+currentShiftCount(),26,GREEN,true));
        row.addView(a,new LinearLayout.LayoutParams(0,110,1)); row.addView(b,new LinearLayout.LayoutParams(0,110,1)); content.addView(row); addSpace(12);

        Button sell=btn("🛒  تسجيل بيع"); sell.setOnClickListener(v->showSales()); content.addView(sell,lp(60)); addSpace(8);
        Button add=btn("📦  إضافة بضاعة"); add.setOnClickListener(v->addProductDialog(-1)); content.addView(add,lp(60)); addSpace(8);
        Button inv=btn("🔍  جرد المخزون"); inv.setOnClickListener(v->showProducts()); content.addView(inv,lp(60)); addSpace(14);

        LinearLayout notes=card(); notes.addView(tv("📝 ملاحظات الوردية",16,TEXT,true));
        EditText ne=new EditText(this); ne.setHint("اكتب ملاحظاتك هنا..."); ne.setGravity(Gravity.TOP|Gravity.RIGHT); ne.setText(pref("current_notes","")); ne.setMinHeight(150); ne.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES); ne.setVerticalScrollBarEnabled(true);
        ne.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){put("current_notes",s.toString());} public void afterTextChanged(Editable e){}});
        notes.addView(ne,new LinearLayout.LayoutParams(-1,170)); content.addView(notes); addSpace(14);

        LinearLayout low=card(); low.addView(tv("⚠ المخزون المنخفض",16,TEXT,true)); JSONArray p=products(); boolean any=false;
        for(int i=0;i<p.length();i++)try{JSONObject o=p.getJSONObject(i); if(o.optInt("qty",0)<=3){any=true; low.addView(tv(o.optString("name")+" — "+o.optInt("qty")+" متوفر",14,Color.rgb(180,110,0),false));}}catch(Exception ignored){}
        if(!any) low.addView(tv("لا توجد أصناف منخفضة المخزون.",14,Color.DKGRAY,false)); content.addView(low);
    }

    void startShift(){
        String id=String.valueOf(System.currentTimeMillis()); prefs.edit().putBoolean("shift_active",true).putString("shift_id",id).putString("shift_start",now()).putString("current_notes","").apply(); showHome();
    }
    void endShift(){
        new AlertDialog.Builder(this).setTitle("إنهاء الوردية").setMessage("سيتم حفظ المبيعات والملاحظات في سجل الوردية وبدء صفحة جديدة.")
            .setNegativeButton("إلغاء",null).setPositiveButton("إنهاء",(d,w)->{
                try{
                    JSONObject sh=new JSONObject(); sh.put("id",shiftId()); sh.put("date",dateOnly()); sh.put("start",pref("shift_start","")); sh.put("end",now()); sh.put("sales",currentShiftSales()); sh.put("count",currentShiftCount()); sh.put("notes",pref("current_notes",""));
                    JSONArray a=shifts(); a.put(sh); save("shifts",a);
                }catch(Exception ignored){}
                prefs.edit().putBoolean("shift_active",false).putString("shift_id","").putString("shift_start","").putString("current_notes","").apply(); showHome();
            }).show();
    }

    void showProducts(){
        clear("المنتجات"); Button add=btn("+  إضافة منتج"); add.setOnClickListener(v->addProductDialog(-1)); content.addView(add,lp(58)); addSpace(10);
        JSONArray p=products(); if(p.length()==0){content.addView(tv("لا توجد منتجات. ابدأ بإضافة أول منتج.",16,TEXT,false));return;}
        for(int i=0;i<p.length();i++)try{ JSONObject o=p.getJSONObject(i); LinearLayout c=card();
            c.addView(tv(o.optString("name"),18,TEXT,true)); c.addView(tv("السعر: "+fmt(o.optDouble("price"))+" ج.س",14,Color.DKGRAY,false)); c.addView(tv("الكمية: "+o.optInt("qty"),14,Color.DKGRAY,false));
            Button edit=btn("تعديل المنتج"); edit.setOnClickListener(v->addProductDialog(i)); c.addView(edit,lp(50)); content.addView(c,lp(165)); addSpace(8);
        }catch(Exception ignored){}
    }
    String fmt(double d){return String.format(Locale.US,"%.0f",d);}

    void addProductDialog(int index){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(8,4,8,4);
        EditText name=field("اسم المنتج",false), price=field("سعر البيع",true), qty=field("الكمية",true); box.addView(name);box.addView(price);box.addView(qty);
        if(index>=0)try{JSONObject o=products().getJSONObject(index);name.setText(o.optString("name"));price.setText(fmt(o.optDouble("price")));qty.setText(""+o.optInt("qty"));}catch(Exception ignored){}
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle(index<0?"إضافة منتج":"تعديل المنتج").setView(box).setNegativeButton("إلغاء",null);
        b.setPositiveButton("حفظ",(d,w)->{try{String n=name.getText().toString().trim();double pr=Double.parseDouble(price.getText().toString());int q=Integer.parseInt(qty.getText().toString());if(n.isEmpty()||pr<0||q<0)throw new Exception();JSONArray p=products();JSONObject o=index<0?new JSONObject():p.getJSONObject(index);o.put("name",n);o.put("price",pr);o.put("qty",q);if(index<0)p.put(o);save("products",p);showProducts();}catch(Exception e){Toast.makeText(this,"أدخل بيانات صحيحة.",Toast.LENGTH_SHORT).show();}});
        if(index>=0)b.setNeutralButton("حذف",(d,w)->deleteProduct(index)); b.show();
    }
    EditText field(String hint,boolean number){EditText e=new EditText(this);e.setHint(hint);e.setGravity(Gravity.RIGHT);if(number)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);return e;}
    void deleteProduct(int index){new AlertDialog.Builder(this).setTitle("حذف المنتج").setMessage("هل تريد حذف هذا المنتج؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{JSONArray p=products();p.remove(index);save("products",p);showProducts();}).show();}

    void showSales(){
        clear("المبيعات"); JSONArray p=products();
        if(!activeShift()){content.addView(tv("ابدأ الوردية أولاً لتسجيل المبيعات.",16,TEXT,false));Button st=btn("▶ بدء الوردية");st.setOnClickListener(v->startShift());content.addView(st,lp(58));return;}
        if(p.length()==0){content.addView(tv("أضف منتجات أولاً حتى تتمكن من تسجيل البيع.",16,TEXT,false));return;}
        Spinner sp=new Spinner(this);String[] names=new String[p.length()];for(int i=0;i<p.length();i++)try{names[i]=p.getJSONObject(i).optString("name");}catch(Exception e){names[i]="منتج";}
        sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));content.addView(tv("اختر المنتج",15,TEXT,true));content.addView(sp,lp(58));addSpace(8);
        EditText q=field("الكمية",true);q.setText("1");content.addView(q,lp(58));addSpace(10);
        Button record=btn("تسجيل البيع");record.setOnClickListener(v->{try{int idx=sp.getSelectedItemPosition(),qty=Integer.parseInt(q.getText().toString());JSONObject o=p.getJSONObject(idx);int stock=o.optInt("qty");if(qty<=0||qty>stock)throw new Exception();double total=o.optDouble("price")*qty;o.put("qty",stock-qty);p.put(idx,o);save("products",p);JSONObject sale=new JSONObject();sale.put("product",o.optString("name"));sale.put("qty",qty);sale.put("total",total);sale.put("time",now());sale.put("shiftId",shiftId());JSONArray s=sales();s.put(sale);save("sales",s);Toast.makeText(this,"تم تسجيل البيع بنجاح ✓",Toast.LENGTH_SHORT).show();showHome();}catch(Exception e){Toast.makeText(this,"الكمية غير متاحة أو البيانات غير صحيحة.",Toast.LENGTH_SHORT).show();}});content.addView(record,lp(60));addSpace(14);
        LinearLayout list=card();list.addView(tv("مبيعات الوردية الحالية",16,TEXT,true));JSONArray s=sales();boolean any=false;for(int i=s.length()-1;i>=0;i--)try{JSONObject x=s.getJSONObject(i);if(shiftId().equals(x.optString("shiftId"))){any=true;list.addView(tv(x.optString("product")+" × "+x.optInt("qty")+" — "+fmt(x.optDouble("total"))+" ج.س",14,TEXT,false));}}catch(Exception ignored){}if(!any)list.addView(tv("لا توجد مبيعات بعد.",14,Color.DKGRAY,false));content.addView(list);
    }

    void showReports(){clear("التقارير");LinearLayout c=card();c.addView(tv("إجمالي كل المبيعات",15,Color.DKGRAY,false));c.addView(tv(fmt(allSales())+" ج.س",30,GREEN,true));c.addView(tv("عدد عمليات البيع: "+sales().length(),15,TEXT,false));content.addView(c,lp(145));addSpace(12);content.addView(tv("التقارير التفصيلية يمكن توسيعها لاحقاً إلى يومية وأسبوعية وشهرية.",14,Color.DKGRAY,false));}

    void showShiftHistory(){clear("سجل الوردية");JSONArray a=shifts();if(a.length()==0){content.addView(tv("لا توجد ورديات مكتملة بعد.",16,TEXT,false));return;}for(int i=a.length()-1;i>=0;i--)try{JSONObject sh=a.getJSONObject(i);LinearLayout c=card();c.addView(tv("وردية — "+displayDate(sh.optString("date")),18,TEXT,true));c.addView(tv("المبيعات: "+fmt(sh.optDouble("sales"))+" ج.س  •  العمليات: "+sh.optInt("count"),14,Color.DKGRAY,false));Button detail=btn("عرض التفاصيل");detail.setOnClickListener(v->showShiftDetails(sh));c.addView(detail,lp(52));content.addView(c,lp(135));addSpace(8);}catch(Exception ignored){}}
    void showShiftDetails(JSONObject sh){
        clear("تفاصيل الوردية");LinearLayout c=card();c.addView(tv("التاريخ: "+displayDate(sh.optString("date")),16,TEXT,true));c.addView(tv("البداية: "+sh.optString("start"),14,Color.DKGRAY,false));c.addView(tv("النهاية: "+sh.optString("end"),14,Color.DKGRAY,false));c.addView(tv("مبيعات الوردية: "+fmt(sh.optDouble("sales"))+" ج.س",18,GREEN,true));c.addView(tv("عمليات البيع: "+sh.optInt("count"),14,TEXT,false));content.addView(c);addSpace(10);
        LinearLayout notes=card();notes.addView(tv("📝 ملاحظات الوردية",16,TEXT,true));String nt=sh.optString("notes","");notes.addView(tv(nt.isEmpty()?"لا توجد ملاحظات.":nt,14,TEXT,false));content.addView(notes);addSpace(12);
        LinearLayout salesBox=card();salesBox.addView(tv("تفاصيل المبيعات",16,TEXT,true));JSONArray s=sales();boolean any=false;for(int i=0;i<s.length();i++)try{JSONObject x=s.getJSONObject(i);if(sh.optString("id").equals(x.optString("shiftId"))){any=true;salesBox.addView(tv(x.optString("product")+" × "+x.optInt("qty")+" — "+fmt(x.optDouble("total"))+" ج.س",14,TEXT,false));}}catch(Exception ignored){}if(!any)salesBox.addView(tv("لا توجد تفاصيل مسجلة لهذه الوردية.",14,Color.DKGRAY,false));content.addView(salesBox);
    }

    void showCustomers(){
        clear("العملاء والديون");Button add=btn("+ إضافة عميل");add.setOnClickListener(v->customerDialog(-1));content.addView(add,lp(58));addSpace(10);
        JSONArray a=customers();if(a.length()==0){content.addView(tv("لا يوجد عملاء بعد.",16,TEXT,false));return;}for(int i=0;i<a.length();i++)try{JSONObject o=a.getJSONObject(i);LinearLayout c=card();c.addView(tv(o.optString("name"),18,TEXT,true));c.addView(tv("التواصل: "+o.optString("contact","غير مضاف"),14,Color.DKGRAY,false));c.addView(tv("الدين: "+fmt(o.optDouble("debt"))+" ج.س",16,o.optDouble("debt")>0?Color.rgb(180,70,50):GREEN,true));Button open=btn("فتح حساب العميل");open.setOnClickListener(v->showCustomerDetails(i));c.addView(open,lp(52));content.addView(c,lp(170));addSpace(8);}catch(Exception ignored){}
    }
    void customerDialog(int index){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);EditText name=field("اسم العميل",false),contact=field("رقم الهاتف / التواصل",false);box.addView(name);box.addView(contact);if(index>=0)try{JSONObject o=customers().getJSONObject(index);name.setText(o.optString("name"));contact.setText(o.optString("contact"));}catch(Exception ignored){}new AlertDialog.Builder(this).setTitle(index<0?"إضافة عميل":"تعديل بيانات العميل").setView(box).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{try{String n=name.getText().toString().trim();if(n.isEmpty())throw new Exception();JSONArray a=customers();JSONObject o=index<0?new JSONObject():a.getJSONObject(index);o.put("name",n);o.put("contact",contact.getText().toString().trim());if(!o.has("debt"))o.put("debt",0);if(!o.has("history"))o.put("history",new JSONArray());if(index<0)a.put(o);save("customers",a);showCustomers();}catch(Exception e){Toast.makeText(this,"أدخل اسم العميل.",Toast.LENGTH_SHORT).show();}}).show();}
    void showCustomerDetails(int index){
        JSONArray a=customers();try{JSONObject o=a.getJSONObject(index);clear("حساب العميل");content.addView(tv(o.optString("name"),22,TEXT,true));content.addView(tv("التواصل: "+o.optString("contact","غير مضاف"),14,Color.DKGRAY,false));addSpace(8);LinearLayout bal=card();bal.addView(tv("الدين الحالي",14,Color.DKGRAY,false));bal.addView(tv(fmt(o.optDouble("debt"))+" ج.س",28,o.optDouble("debt")>0?Color.rgb(180,70,50):GREEN,true));content.addView(bal);addSpace(10);
            Button plus=btn("+ إضافة دين");plus.setOnClickListener(v->changeDebt(index,true));content.addView(plus,lp(58));addSpace(8);Button minus=btn("− سداد / خصم من الدين");minus.setOnClickListener(v->changeDebt(index,false));content.addView(minus,lp(58));addSpace(8);Button edit=btn("تعديل بيانات العميل");edit.setOnClickListener(v->customerDialog(index));content.addView(edit,lp(58));addSpace(14);
            LinearLayout h=card();h.addView(tv("سجل الدين",16,TEXT,true));JSONArray hist=o.optJSONArray("history");if(hist==null||hist.length()==0)h.addView(tv("لا توجد عمليات بعد.",14,Color.DKGRAY,false));else for(int j=hist.length()-1;j>=0;j--)try{JSONObject z=hist.getJSONObject(j);h.addView(tv((z.optBoolean("add")?"+ دين":"− سداد")+"  "+fmt(z.optDouble("amount"))+" ج.س — "+z.optString("time"),14,TEXT,false));}catch(Exception ignored){}content.addView(h);
        }catch(Exception ignored){}
    }
    void changeDebt(int index,boolean add){EditText amount=field(add?"مبلغ الدين":"مبلغ السداد",true);new AlertDialog.Builder(this).setTitle(add?"إضافة دين":"سداد / خصم").setView(amount).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{try{double v=Double.parseDouble(amount.getText().toString());if(v<=0)throw new Exception();JSONArray a=customers();JSONObject o=a.getJSONObject(index);double debt=o.optDouble("debt");if(!add&&v>debt)throw new Exception();o.put("debt",add?debt+v:debt-v);JSONArray h=o.optJSONArray("history");if(h==null)h=new JSONArray();JSONObject z=new JSONObject();z.put("amount",v);z.put("add",add);z.put("time",now());h.put(z);o.put("history",h);a.put(index,o);save("customers",a);showCustomerDetails(index);}catch(Exception e){Toast.makeText(this,add?"أدخل مبلغاً صحيحاً.":"مبلغ السداد أكبر من الدين أو غير صحيح.",Toast.LENGTH_SHORT).show();}}).show();}
}
